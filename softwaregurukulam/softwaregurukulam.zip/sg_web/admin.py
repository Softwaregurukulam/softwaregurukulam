from django.contrib import admin
from sg_web.models import Category,Course

admin.site.register(Category)
admin.site.register(Course)
