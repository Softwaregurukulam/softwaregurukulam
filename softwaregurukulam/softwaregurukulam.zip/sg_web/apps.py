from django.apps import AppConfig


class sg_webConfig(AppConfig):
    name = 'sg_web'
